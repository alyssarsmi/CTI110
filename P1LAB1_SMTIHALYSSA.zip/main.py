user_name =input('Hello Pat and welcome to CS Online!')
''' Type your code here. '''